package com.example.app_aplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Iniciar_Sesion extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_iniciar__sesion);
    }
}
